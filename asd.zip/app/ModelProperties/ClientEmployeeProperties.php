<?php

namespace App\ModelProperties;

/**
 * Propiedades declarativas de ClientEmployee (hijo has_many de Client).
 */
class ClientEmployeeProperties
{
    /**
     * Esquema de campos para meta, tabla y formulario anidado.
     *
     * @return array<int, array<string, mixed>>
     */
    public static function all()
    {
        return [
            [
                'key' => 'name',
                'text' => 'Nombre',
                'type' => 'text',
                'value' => '',
                'show' => true,
                'use_to_filter_in_search' => true,
                'width' => 180,
            ],
            [
                'key' => 'phone',
                'text' => 'Teléfono',
                'type' => 'text',
                'value' => '',
                'show' => true,
                'use_to_filter_in_search' => true,
                'width' => 140,
            ],
            [
                'key' => 'notes',
                'text' => 'Notas',
                'type' => 'textarea',
                'value' => '',
                'show' => true,
                'full_width' => true,
                'wrap_content' => true,
                'width' => 220,
            ],
            [
                // Permiso para usar el canal "sistema:" de WhatsApp (consultar stock, ventas, facturas, clientes).
                'key' => 'can_query_system',
                'text' => 'Puede consultar el sistema por WhatsApp',
                'type' => 'checkbox',
                'value' => false,
                'show' => true,
                'width' => 120,
            ],
            [
                'key' => 'empresa_employee_id',
                'text' => 'ID empresa',
                'type' => 'number',
                'value' => null,
                'only_show' => true,
                'not_show_on_table' => true,
                'exclude_on_update' => true,
            ],
        ];
    }
}
